const express = require('express');
const path = require('path');
const knex = require('knex');
const knexConfig = require('./knexfile.js');
const session = require('express-session');

const app = express();
const db = knex(knexConfig.development);


// Middleware to parse JSON bodies
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public'))); // Serve static files from the public directory

// Session middleware configuration
app.use(session({
    secret: 'your_secret_key', // A secret key for signing the session ID cookie
    resave: false,              // Forces session to be saved back to the session store, even if it was never modified
    saveUninitialized: true,    // Forces an uninitialized session to be saved to the store
    cookie: { secure: false }   // Set to true if you're using HTTPS
}));

// Log in route
app.post('/login', async (req, res) => {
    const { email, password } = req.body;
    try {
        const user = await db('users').where({ email, password }).first();
        if (user) {
            req.session.user = user; // Store user data in session
            res.json({ message: 'Autentificare reușită!' });
        } else {
            res.status(401).json({ error: 'Email sau parolă incorectă!' });
        }
    } catch (error) {
        console.error('Error during login:', error);
        res.status(500).json({ error: 'Eroare la autentificare!' });
    }
});

// Route to handle registration
app.post('/register', async (req, res) => {
    const { email, password } = req.body;

    // Verify if both email and password were provided
    if (!email || !password) {
        console.log('Missing email or password');
        return res.status(400).json({ error: 'Email și parolă sunt necesare!' });
    }

    try {
        console.log(`Checking if user with email ${email} already exists...`);

        // Check if the user already exists in the database
        const existingUser = await db('users').where({ email }).first();

        if (existingUser) {
            console.log('User already exists:', existingUser);
            return res.status(400).json({ error: 'Utilizatorul există deja!' });
        }

        // Insert the new user into the 'users' table
        const [newUserId] = await db('users').insert({ email, password, experience: 0 });
        console.log(`New user created with ID: ${newUserId}`);

        // After creating the new user, create an empty progress record in 'user_progress'
        await db('user_progress').insert({
            user_id: newUserId,
            chapter1: 0,
            chapter2: 0,
            chapter3: 0,
            chapter4: 0,
            chapter5: 0,
            chapter6: 0,
            chapter7: 0,
            chapter8: 0,
            chapter9: 0
        });

        console.log(`User progress initialized for user ID: ${newUserId}`);

        // Send success response
        res.json({ message: 'Înregistrare reușită! Vă rugăm să vă autentificați.' });
    } catch (error) {
        console.error('Error during registration:', error);
        res.status(500).json({ error: 'Eroare la înregistrarea utilizatorului!' });
    }
});

// Route to get user data for the dashboard
app.get('/dashboard', async (req, res) => {
    if (!req.session.user) {
        return res.status(401).json({ error: 'Autentificare necesară!' });
    }

    try {
        const user = await db('users').where({ id: req.session.user.id }).first();
        if (user) {
            res.json({
                email: user.email,
                experience: user.experience || 0
            });
        } else {
            res.status(404).json({ error: 'Utilizatorul nu a fost găsit!' });
        }
    } catch (error) {
        console.error('Error fetching dashboard data:', error);
        res.status(500).json({ error: 'Eroare la preluarea datelor utilizatorului!' });
    }
});

// Route to get chapters and progress
app.get('/chapters', async (req, res) => {
    if (!req.session.user) {
        return res.status(401).json({ error: 'Autentificare necesară!' });
    }

    try {
        const chapters = await db('chapters').select('*');
        const progress = await db('user_progress').where({ user_id: req.session.user.id }).first();

        const formattedChapters = chapters.map((chapter, index) => {
            const chapterProgress = progress ? progress[`chapter${index + 1}`] : 0;
            return {
                ...chapter,
                title: chapterProgress === 1 
                    ? `${chapter.title} <span class="completed">(COMPLETAT)</span>` 
                    : chapter.title
            };
        });

        res.json(formattedChapters);
    } catch (error) {
        console.error('Error fetching chapters or progress:', error);
        res.status(500).json({ error: 'Eroare la preluarea capitolelor sau progresului!' });
    }
});

// Route to get questions for a specific chapter
app.get('/chapters/:chapter_id/questions', async (req, res) => {
    const { chapter_id } = req.params;
    try {
        const questions = await db('questions').where({ chapter_id });
        res.json(questions);
    } catch (error) {
        console.error('Error fetching questions:', error);
        res.status(500).json({ error: 'Eroare la preluarea întrebărilor!' });
    }
});

// Route to update user's score after completing the quiz
app.post('/update-score', async (req, res) => {
    if (!req.session.user) {
        return res.status(401).json({ error: 'Autentificare necesară!' });
    }

    const { xp } = req.body;

    if (typeof xp !== 'number' || xp < 0) {
        return res.status(400).json({ error: 'XP invalid!' });
    }

    try {
        await db('users')
            .where({ id: req.session.user.id })
            .increment('experience', xp);

        res.json({ success: true });
    } catch (error) {
        console.error('Error updating user XP:', error);
        res.status(500).json({ error: 'Eroare la actualizarea XP-ului utilizatorului!' });
    }
});

// Route to mark a chapter as completed
app.post('/complete-chapter', async (req, res) => {
    if (!req.session.user) {
        return res.status(401).json({ error: 'Autentificare necesară!' });
    }

    const { chapter_id } = req.body;

    // Validate the chapter_id
    if (typeof chapter_id !== 'number' || isNaN(chapter_id) || chapter_id < 1) {
        return res.status(400).json({ error: 'Capitol invalid!' });
    }

    try {
        const columnToUpdate = `chapter${chapter_id}`;
        await db('user_progress')
            .where({ user_id: req.session.user.id })
            .update({ [columnToUpdate]: 1 });

        res.json({ success: true });
    } catch (error) {
        console.error('Error updating chapter progress:', error);
        res.status(500).json({ error: 'Eroare la actualizarea progresului capitolului!' });
    }
});

// Route to handle logout
app.post('/logout', (req, res) => {
    if (req.session) {
        req.session.destroy(err => {
            if (err) {
                console.error('Error destroying session:', err);
                return res.status(500).json({ error: 'Eroare la deconectare!' });
            }
            res.json({ message: 'Deconectare reușită!' });
        });
    } else {
        res.status(400).json({ error: 'Sesiunea nu a fost găsită!' });
    }
});

// Test database connection
app.get('/test-db', async (req, res) => {
    try {
        const result = await db('user_progress').select('*');
        res.json(result);
    } catch (error) {
        console.error('Database connection issue:', error);
        res.status(500).json({ error: 'Database connection failed.' });
    }
});

app.get('/user-progress', async (req, res) => {
    if (!req.session.user) {
        console.error('User session not found.');
        return res.status(401).json({ error: 'Autentificare necesară!' });
    }

    try {
        const userId = req.session.user.id;
        console.log(`Fetching progress for user ID: ${userId}`);

        // Fetch progress for the logged-in user
        const progress = await db('user_progress').where({ user_id: userId }).first();

        if (!progress) {
            console.warn('No progress found for user ID:', userId);
            return res.status(404).json({ error: 'Progresul nu a fost găsit pentru acest utilizator!' });
        }

        console.log('Progress fetched successfully:', progress);
        res.json(progress);
    } catch (error) {
        console.error('Error fetching user progress:', error);
        res.status(500).json({ error: 'Eroare la preluarea progresului utilizatorului!' });
    }
});


// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
