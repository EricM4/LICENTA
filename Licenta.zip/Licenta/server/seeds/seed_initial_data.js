exports.seed = function(knex) {
  return knex('chapters').del() // Clear existing entries
      .then(() => {
          return knex('chapters').insert([
              { id: 1, name: 'Introduction to the English Language', description: 'Presentation of the English alphabet, basic pronunciation, greetings' },
              { id: 2, name: 'Basic Verbs and Expressions', description: 'Essential verbs: "to be", "to have", "to do"' },
              // Add other chapters...
          ]);
      });
};