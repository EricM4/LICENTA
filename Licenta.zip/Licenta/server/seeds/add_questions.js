exports.seed = function(knex) {
  // Deletes ALL existing entries
  return knex('questions').del()
      .then(function () {
          // Inserts seed entries
          return knex('questions').insert([
              {
                  quiz_id: 1,
                  text: 'Ce literă urmează după "A" în alfabetul englez?',
                  options: JSON.stringify(['B', 'C', 'D', 'E']),
                  correct_option: 'B'
              },
              {
                  quiz_id: 1,
                  text: 'Cum se spune "Salut" în engleză?',
                  options: JSON.stringify(['Hello', 'Goodbye', 'Please', 'Thank you']),
                  correct_option: 'Hello'
              },
              // More questions for different quizzes/chapters
          ]);
      });
};