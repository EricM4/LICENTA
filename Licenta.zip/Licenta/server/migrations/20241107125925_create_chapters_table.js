exports.up = function(knex) {
    return knex.schema.createTable('chapters', (table) => {
        table.increments('id').primary();
        table.string('name').notNullable();
        table.text('description').notNullable();
    });
};

exports.down = function(knex) {
    return knex.schema.dropTableIfExists('chapters');
};
