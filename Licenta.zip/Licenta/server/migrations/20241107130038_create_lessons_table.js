exports.up = function(knex) {
    return knex.schema.createTable('lessons', (table) => {
        table.increments('id').primary();
        table.string('title').notNullable();
        table.integer('chapter_id').unsigned().notNullable();
        table.foreign('chapter_id').references('chapters.id');
        table.text('content').notNullable();
    });
};

exports.down = function(knex) {
    return knex.schema.dropTableIfExists('lessons');
};
