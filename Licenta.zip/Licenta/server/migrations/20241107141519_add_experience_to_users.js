exports.up = function(knex) {
    return knex.schema.table('users', function(table) {
      table.integer('experience').defaultTo(0); // Add experience column with a default value of 0
    });
  };
  
  exports.down = function(knex) {
    return knex.schema.table('users', function(table) {
      table.dropColumn('experience'); // Drop the experience column if rollback is needed
    });
  };