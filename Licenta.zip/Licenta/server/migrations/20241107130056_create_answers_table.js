exports.up = function(knex) {
    return knex.schema.createTable('answers', (table) => {
        table.increments('id').primary();
        table.integer('question_id').unsigned().notNullable();
        table.foreign('question_id').references('questions.id');
        table.text('answer_text').notNullable();
        table.boolean('is_correct').notNullable();
    });
};

exports.down = function(knex) {
    return knex.schema.dropTableIfExists('answers');
};
