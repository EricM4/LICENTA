exports.up = function(knex) {
    return knex.schema.createTable('user_progress', (table) => {
        table.increments('id').primary();
        table.integer('user_id').unsigned().notNullable().references('id').inTable('users').onDelete('CASCADE');
        table.integer('chapter_id').unsigned().notNullable().references('id').inTable('chapters').onDelete('CASCADE');
        table.boolean('finished').defaultTo(false);
    });
};

exports.down = function(knex) {
    return knex.schema.dropTable('user_progress');
};