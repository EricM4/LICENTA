exports.up = function(knex) {
    return knex.schema.createTable('questions', (table) => {
        table.increments('id').primary();
        table.integer('quiz_id').unsigned().notNullable().references('id').inTable('quizzes').onDelete('CASCADE');
        table.string('text').notNullable();
        table.json('options').notNullable(); // Stores multiple choice options as JSON
        table.string('correct_option').notNullable(); // Stores the correct answer option
    });
};

exports.down = function(knex) {
    return knex.schema.dropTable('questions');
};
