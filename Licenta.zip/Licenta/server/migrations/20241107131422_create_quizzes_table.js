exports.up = function(knex) {
    return knex.schema.createTable('quizzes', function(table) {
      table.increments('id').primary();                       // Unique ID for each quiz
      table.integer('chapter_id').unsigned().notNullable()    // Foreign key to reference chapters
           .references('id').inTable('chapters')
           .onDelete('CASCADE');                               // If a chapter is deleted, delete the associated quizzes
      table.string('title', 255).notNullable();               // Quiz title
      table.string('description', 255).notNullable();         // Quiz description
    });
  };
  
  exports.down = function(knex) {
    return knex.schema.dropTableIfExists('quizzes');          // Drop quizzes table if it exists
  };