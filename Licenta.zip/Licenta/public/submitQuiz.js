document.addEventListener('DOMContentLoaded', () => {
    console.log('DOMContentLoaded event triggered.');

    const submitQuizButton = document.getElementById('submit-quiz');
    const backChaptersButton = document.getElementById('back-chapters');
    const backDashboardButton = document.getElementById('back-dashboard'); // For Back to Dashboard button

    // Ensure the "Back to Chapters" button works
    if (backChaptersButton) {
        backChaptersButton.addEventListener('click', () => {
            console.log('Back to chapters button clicked.');
            window.location.href = '/chapters.html';
        });
    }

    // Ensure the "Back to Dashboard" button works
    if (backDashboardButton) {
        backDashboardButton.addEventListener('click', () => {
            console.log('Back to dashboard button clicked');
            window.location.href = '/dashboard.html';
        });
    }

    // Add event listener for quiz submission
    if (submitQuizButton) {
        submitQuizButton.addEventListener('click', async () => {
            const allQuestions = document.querySelectorAll('.question');
            let allAnswered = true;
            let correctAnswersCount = 0;

            // Check if every question has been answered and evaluate correctness
            allQuestions.forEach(questionDiv => {
                const questionId = questionDiv.getAttribute('data-question-id');
                const selectedOption = questionDiv.querySelector(`input[name="question${questionId}"]:checked`);
                const correctAnswer = questionDiv.getAttribute('data-correct-answer');

                if (!selectedOption) {
                    allAnswered = false;
                } else if (selectedOption.value === correctAnswer) {
                    correctAnswersCount++;
                } else {
                    // Highlight wrong answers in red
                    const parentLabel = selectedOption.parentElement;
                    parentLabel.style.color = 'red';
                }
            });

            if (allAnswered) {
                alert('Quiz completat!');

                // Award XP based on the number of correct answers
                const xpToAward = correctAnswersCount * 10; // Award 10 XP per correct answer
                try {
                    await updateUserXP(xpToAward);
                    console.log('XP updated successfully');

                    // Mark chapter as completed if all answers are correct
                    if (correctAnswersCount === allQuestions.length) {
                        const currentChapterId = parseInt(new URLSearchParams(window.location.search).get('chapter_id'), 10);
                        await markChapterAsCompleted(currentChapterId);
                        console.log('Chapter marked as completed successfully');

                        window.location.href = '/dashboard.html'; // Redirect to dashboard after successful completion
                    } else {
                        alert('Nu toate răspunsurile sunt corecte. Încercați din nou pentru a finaliza capitolul!');
                    }
                } catch (error) {
                    console.error('Error during quiz submission:', error.message);
                    alert('Eroare la trimiterea quizului. Te rog verifică și încearcă din nou.');
                }
            } else {
                alert('Vă rugăm să răspundeți la toate întrebările înainte de a trimite!');
            }
        });
    }
});

// Function to update user's XP
async function updateUserXP(xp) {
    try {
        console.log('Attempting to update user XP with:', xp);
        const response = await fetch('/update-score', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ xp }),
            credentials: 'same-origin' // Ensure session data is used
        });

        if (!response.ok) {
            throw new Error('Eroare la actualizarea XP-ului utilizatorului!');
        }

        const responseData = await response.json();
        console.log('User XP updated successfully:', responseData);
    } catch (error) {
        console.error('Error:', error.message);
        throw new Error('Nu s-a putut actualiza XP-ul!');
    }
}

// Function to mark chapter as completed
async function markChapterAsCompleted(chapterId) {
    try {
        console.log('Attempting to mark chapter as completed for chapter ID:', chapterId);

        const response = await fetch('/complete-chapter', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ chapter_id: chapterId }),
            credentials: 'same-origin' // Ensure session data is used
        });

        if (!response.ok) {
            throw new Error('Eroare la actualizarea progresului capitolului!');
        }

        const responseData = await response.json();
        console.log('Server response for markChapterAsCompleted:', responseData);

        if (!responseData.success) {
            console.warn('Progress update failed or was not marked as completed.');
            throw new Error('Eroare la actualizarea progresului!');
        }
    } catch (error) {
        console.error('Error updating chapter progress:', error.message);
        throw new Error('Nu s-a putut actualiza progresul! Te rog verifică și încearcă din nou.');
    }
}
