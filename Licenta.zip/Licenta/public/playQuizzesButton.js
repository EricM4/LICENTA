// playQuizButton.js

document.addEventListener('DOMContentLoaded', () => {
    const playQuizButton = document.getElementById('play-quiz');
    if (playQuizButton) {
        playQuizButton.addEventListener('click', () => {
            window.location.href = '/chapters.html'; // Redirect to the chapters selection page
        });
    }
});