document.addEventListener('DOMContentLoaded', () => {
    console.log('DOMContentLoaded event triggered.');

    const chaptersList = document.getElementById('chapters-list');
    const backButton = document.getElementById('back-to-dashboard');

    if (backButton) {
        backButton.addEventListener('click', () => {
            console.log('Back to dashboard button clicked');
            window.location.href = '/dashboard.html'; // Redirect to dashboard.html
        });
    }

    if (chaptersList) {
        console.log('Fetching chapters and user progress...');
        Promise.all([
            fetch('/chapters', { credentials: 'same-origin' }).then(response => {
                if (!response.ok) {
                    console.error('Error fetching chapters:', response.status, response.statusText);
                    throw new Error('Eroare la preluarea capitolelor');
                }
                return response.json();
            }),
            fetch('/user-progress', { credentials: 'same-origin' }).then(response => {
                if (!response.ok) {
                    console.error('Error fetching user progress:', response.status, response.statusText);
                    throw new Error('Eroare la preluarea progresului utilizatorului');
                }
                return response.json();
            })
        ])
        .then(([chapters, userProgress]) => {
            console.log('Chapters fetched:', chapters);
            console.log('User progress fetched:', userProgress);

            // Clear the loading message
            const loadingMessage = document.getElementById('loading-message');
            if (loadingMessage) {
                loadingMessage.remove();
            }

            // Render each chapter button on the page
            chapters.forEach((chapter, index) => {
                const button = document.createElement('button');
                button.classList.add('chapter');
                button.textContent = `${chapter.name}`;

                // Check if the chapter is completed by the user
                const chapterKey = `chapter${chapter.id}`;
                if (userProgress[chapterKey] === 1) {
                    const completedSpan = document.createElement('span');
                    completedSpan.classList.add('completed');
                    completedSpan.textContent = ' (COMPLETAT)';
                    button.appendChild(completedSpan); // Add the completed span to the button
                }

                button.setAttribute('data-chapter-id', chapter.id);
                chaptersList.appendChild(button);

                console.log(`Button created for chapter ID: ${chapter.id}`);
            });
        })
        .catch(error => {
            console.error('Error:', error.message);
            alert('Eroare la încărcarea capitolelor sau progresului.');
        });

        // Event listener for clicking chapter buttons
        chaptersList.addEventListener('click', (event) => {
            const target = event.target.closest('.chapter');
            if (target) {
                const chapterId = target.getAttribute('data-chapter-id');
                console.log(`Navigating to quizzes for chapter ID: ${chapterId}`);
                window.location.href = `/quizzes.html?chapter_id=${chapterId}`;
            }
        });
    }
});
