document.addEventListener('DOMContentLoaded', () => {
    const backDashboardButton = document.getElementById('back-dashboard');
    if (backDashboardButton) {
        backDashboardButton.addEventListener('click', () => {
            window.location.href = '/dashboard.html';
        });
    }
});