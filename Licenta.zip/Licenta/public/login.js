const loginForm = document.getElementById('login-form');
if (loginForm) {
    loginForm.addEventListener('submit', async (event) => {
        event.preventDefault(); // Prevent form submission

        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;

        console.log('Logging in with:', email, password); // Log form data

        try {
            const response = await fetch('/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ email, password })
            });

            if (response.ok) {
                // Redirect to dashboard on success
                window.location.href = '/dashboard.html';
            } else {
                const error = await response.json();
                alert(error.error); // Show error message
            }
        } catch (error) {
            console.error(error.message);
            alert('Eroare la autentificare.');
        }
    });
}
