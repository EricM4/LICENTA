
// Fetch user data and display it on the dashboard
async function fetchUserData() {
    try {
        const response = await fetch('/dashboard');
        if (!response.ok) throw new Error('Eroare la preluarea datelor utilizatorului');
        const userData = await response.json();

        // Populate the dashboard with user data
        document.getElementById('user-email').innerText = userData.email;
        document.getElementById('user-xp').innerText = userData.experience;
    } catch (error) {
        console.error('Error fetching user data:', error);
        alert('Eroare la preluarea datelor utilizatorului');
    }
}

// Call the function when the page loads
window.onload = fetchUserData;