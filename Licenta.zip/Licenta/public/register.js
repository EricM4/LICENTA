
document.addEventListener('DOMContentLoaded', () => {
    const registerForm = document.getElementById('register-form');
    if (registerForm) {
        registerForm.addEventListener('submit', async (event) => {
            event.preventDefault(); // Prevent form submission

            const email = document.getElementById('register-email').value;
            const password = document.getElementById('register-password').value;

            try {
                const response = await fetch('/register', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ email, password })
                });

                if (response.ok) {
                    // Redirect to login page on success
                    window.location.href = '/login.html';
                } else {
                    const error = await response.json();
                    alert(error.error); // Show error message
                }
            } catch (error) {
                console.error(error.message);
                alert('Eroare la înregistrare.');
            }
        });
    }
});