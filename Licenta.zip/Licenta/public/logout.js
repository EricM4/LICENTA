// Logout functionality
document.addEventListener('DOMContentLoaded', () => {
    const logoutButton = document.getElementById('logout');
    if (logoutButton) {
        logoutButton.addEventListener('click', async () => {
            try {
                const response = await fetch('/logout', {
                    method: 'POST'
                });

                if (response.ok) {
                    window.location.href = '/login.html'; // Redirect to login page after logout
                } else {
                    const error = await response.json();
                    alert(error.error);
                }
            } catch (error) {
                console.error('Eroare la deconectare:', error);
                alert('Eroare la deconectare.');
            }
        });
    }
});
