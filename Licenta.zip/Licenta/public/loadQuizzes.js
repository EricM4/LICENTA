document.addEventListener('DOMContentLoaded', () => {
    console.log('DOMContentLoaded event triggered.');

    const quizQuestions = document.getElementById('quiz-questions');
    const quizImage = document.getElementById('quiz-image');
    const backChaptersButton = document.getElementById('back-chapters');

    if (backChaptersButton) {
        backChaptersButton.addEventListener('click', () => {
            window.location.href = '/chapters.html';
        });
    }

    if (quizQuestions) {
        const chapterId = parseInt(new URLSearchParams(window.location.search).get('chapter_id'), 10);

        if (!isNaN(chapterId)) {
            fetchQuestionsAndImage(chapterId);
        }
    }
});

async function fetchQuestionsAndImage(chapterId) {
    const quizQuestions = document.getElementById('quiz-questions');
    const quizImage = document.getElementById('quiz-image');

    if (quizImage) {
        quizImage.src = `/images/chapters/chapter${chapterId}_background.png`;
        quizImage.alt = `Imagine pentru Capitolul ${chapterId}`;
    }

    try {
        const response = await fetch(`/chapters/${chapterId}/questions`, { credentials: 'same-origin' });
        if (!response.ok) throw new Error('Eroare la preluarea întrebărilor');

        const questions = await response.json();
        renderQuestions(questions);
    } catch (error) {
        console.error('Error:', error.message);
        alert('Eroare la încărcarea întrebărilor.');
    }
}

function renderQuestions(questions) {
    const quizQuestions = document.getElementById('quiz-questions');
    quizQuestions.innerHTML = '';

    questions.forEach((question, index) => {
        const div = document.createElement('div');
        div.classList.add('question');
        div.setAttribute('data-question-id', question.id);
        div.setAttribute('data-correct-answer', question.correct_option);

        let options = question.options;
        if (typeof options === 'string') {
            options = JSON.parse(options);
        }

        div.innerHTML = `
            <p>${index + 1}. ${question.text}</p>
            ${options.map(option => `
                <label>
                    <input type="radio" name="question${question.id}" value="${option}">
                    ${option}
                </label>
            `).join('')}
        `;
        quizQuestions.appendChild(div);
    });
}
