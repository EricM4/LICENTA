
document.addEventListener('DOMContentLoaded', () => {
  // Add event listener for the "Joacă" button
  const playQuizButton = document.getElementById('play-quiz');
  if (playQuizButton) {
      playQuizButton.addEventListener('click', () => {
          window.location.href = '/chapters.html'; // Redirect to the chapters selection page
      });
  }

  // Logout functionality
  const logoutButton = document.getElementById('logout');
  if (logoutButton) {
      logoutButton.addEventListener('click', async () => {
          try {
              await fetch('/logout', { method: 'POST', credentials: 'same-origin' });
              window.location.href = '/login.html'; // Redirect to login page after logout
          } catch (error) {
              console.error('Eroare la deconectare:', error);
              alert('Eroare la deconectare.');
          }
      });
  }
});